#               LOL JK PUNK'D
#       Have fun finding magic numbers! 
#
#                   _____
#                  ||   ||
#                  |\___/|
#                  |     |
#                  |     |
#                  |     |
#                  |     |
#                  |     |
#                  |<-@->|
#              ____|     |____
#         ___ /    |     |    \
#        /    |    |     |    | \
#        |    |    |     |    |  |
#        |    |    |     |    |  |
#        |                    |  |
#        |                       /
#        |                      /
#         \                   /
#          \                 /
#           |                |
#           |                |
#
# Wars Fought                   Stud Service
# Revolutions Started           Tigers Tamed
# Assassinations Plotted        Bars Emptied
# Governments Run         Computers Verified
# Uprisings Quelled         Orgies Organized
