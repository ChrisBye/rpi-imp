_/ _/ _/ To Run _/ _/ _/

To run IMP, you'll need to have installed Python 2.5 or higher (http://www.python.org/), PyGTK (http://www.pygtk.org/), and the Python Imaging Library (http://www.pythonware.com/products/pil/). Run IMP.py with Python and you should be set!
